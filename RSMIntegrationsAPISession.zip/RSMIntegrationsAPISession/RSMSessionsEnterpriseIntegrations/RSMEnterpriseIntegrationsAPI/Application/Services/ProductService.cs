﻿namespace RSMEnterpriseIntegrationsAPI.Application.Services
{
    using CondingBasic3.Models;
    using RSMEnterpriseIntegrationsAPI.Application.DTOs;
    using RSMEnterpriseIntegrationsAPI.Application.Exceptions;
    using RSMEnterpriseIntegrationsAPI.Domain.Interfaces;
    using RSMEnterpriseIntegrationsAPI.Domain.Models;

    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;
        public ProductService(IProductRepository repository)
        {
            _productRepository = repository;
        }

        public async Task<int> CreateProduct(CreateProductDTO productDto)
        {
            if (productDto is null
                || string.IsNullOrWhiteSpace(productDto.Name)
                || string.IsNullOrWhiteSpace(productDto.ProductNumber))
            {
                throw new BadRequestException("Product info is not valid.");
            }

            Product product = new()
            {
                Name = productDto.Name,
                ProductNumber = productDto.ProductNumber,
                // Incluir otros campos necesarios para crear un producto
            };

            return await _productRepository.CreateProduct(product);
        }

        public Task<int> DeleteProduct(int id)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<GetProductDTO>> GetAllProducts()
        {
            throw new NotImplementedException();
        }

        public Task<GetProductDTO?> GetProductById(int id)
        {
            throw new NotImplementedException();
        }

        public Task<int> UpdateProduct(UpdateProductDTO productDto)
        {
            throw new NotImplementedException();
        }

        // Implementar métodos GetAll, GetProductById, UpdateProduct, DeleteProduct
    }
}

