﻿namespace RSMEnterpriseIntegrationsAPI.Application.DTOs
{
    public class GetDepartmentDto
    {
        public short DepartmentId { get; set; }
        public string? Name { get; set; }
        public string? GroupName { get; set; }
    }
}
