﻿namespace RSMEnterpriseIntegrationsAPI.Domain.Interfaces
{
    using RSMEnterpriseIntegrationsAPI.Application.DTOs;

    public interface IProductService
    {
        Task<GetProductDTO?> GetProductById(int id);
        Task<IEnumerable<GetProductDTO>> GetAllProducts();
        Task<int> CreateProduct(CreateProductDTO productDto);
        Task<int> UpdateProduct(UpdateProductDTO productDto);
        Task<int> DeleteProduct(int id);
    }
}

