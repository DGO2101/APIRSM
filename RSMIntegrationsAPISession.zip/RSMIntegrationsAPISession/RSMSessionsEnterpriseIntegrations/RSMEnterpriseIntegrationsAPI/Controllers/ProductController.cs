﻿// ProductController
namespace RSMEnterpriseIntegrationsAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using RSMEnterpriseIntegrationsAPI.Application.DTOs;
    using RSMEnterpriseIntegrationsAPI.Domain.Interfaces;

    [Route("api/product")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _service;

        public ProductController(IProductService service)
        {
            _service = service;
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAllProducts()
        {
            IEnumerable<GetProductDTO> products = await _service.GetAllProducts();
            return Ok(products);
        }

        [HttpGet("Get")]
        public async Task<IActionResult> GetProductById([FromQuery] int id)
        {
            GetProductDTO product = await _service.GetProductById(id);
            if (product == null)
            {
                return NotFound();
            }
            return Ok(product);
        }

        [HttpDelete("Delete/{id:int}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            int result = await _service.DeleteProduct(id);
            if (result == 0)
            {
                return NotFound();
            }
            return Ok(result);
        }

        [HttpPost("Create")]
        public async Task<IActionResult> CreateProduct(CreateProductDTO dto)
        {
            int result = await _service.CreateProduct(dto);
            return Ok(result);
        }

        [HttpPut("Update")]
        public async Task<IActionResult> UpdateProduct(UpdateProductDTO dto)
        {
            int result = await _service.UpdateProduct(dto);
            if (result == 0)
            {
                return NotFound();
            }
            return Ok(result);
        }
    }
}

