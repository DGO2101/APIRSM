﻿// DepartmentController
namespace RSMEnterpriseIntegrationsAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using RSMEnterpriseIntegrationsAPI.Application.DTOs;
    using RSMEnterpriseIntegrationsAPI.Domain.Interfaces;

    [Route("api/department")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly IDepartmentService _service;

        public DepartmentController(IDepartmentService service)
        {
            _service = service;
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAllDepartments()
        {
            IEnumerable<GetDepartmentDto> departments = await _service.GetAll();
            return Ok(departments);
        }

        [HttpGet("Get")]
        public async Task<IActionResult> GetDepartmentById([FromQuery] int id)
        {
            GetDepartmentDto department = await _service.GetDepartmentById(id);
            if (department == null)
            {
                return NotFound();
            }
            return Ok(department);
        }

        [HttpDelete("Delete/{id:int}")]
        public async Task<IActionResult> DeleteDepartment(int id)
        {
            int result = await _service.DeleteDepartment(id);
            if (result == 0)
            {
                return NotFound();
            }
            return Ok(result);
        }

        [HttpPost("Create")]
        public async Task<IActionResult> CreateDepartment(CreateDepartmentDto dto)
        {
            int result = await _service.CreateDepartment(dto);
            return Ok(result);
        }

        [HttpPut("Update")]
        public async Task<IActionResult> UpdateDepartment(UpdateDepartmentDto dto)
        {
            int result = await _service.UpdateDepartment(dto);
            if (result == 0)
            {
                return NotFound();
            }
            return Ok(result);
        }
    }
}
